module com.example.spaceshooter {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;
    requires java.desktop;
    requires java.sql;


    opens com.example.spaceshooter to javafx.fxml;
    exports com.example.spaceshooter;
}