package com.example.spaceshooter;

import com.example.spaceshooter.HelloApplication;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;

public class LogIn {
    @FXML
    private TextField mail;
    @FXML
    private TextField password;
    @FXML
    private Label incorect;



    @FXML
    private void logInButton(ActionEvent e) throws SQLException, IOException {

        if(checkInfo())
        {
            Parent root = FXMLLoader.load(getClass().getResource("MainManu.fxml"));
            Scene scene = new Scene(root);
            Stage stage = (Stage)((Node)e.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        }
    }

    @FXML
    private void passwordTextFiled() throws SQLException {
        if(checkInfo())
        {
            password.clear();
        }
    }

    @FXML
    private void SignUp(ActionEvent e) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("SignUp.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage)((Node)e.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }



    private boolean checkInfo() throws SQLException {
        Connection connection
                = DriverManager.getConnection(HelloApplication.url, HelloApplication.usename, HelloApplication.password);
        String mail1 = mail.getText();
        String password1 = password.getText();
        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery("select * from users");
        boolean indicator = false;
        while(resultSet.next()){
            if(mail1.equals(resultSet.getString(1))
                    && password1.equals(resultSet.getString(2))){
                indicator = true;
                break;
            }
        }


        if(indicator) {
            incorect.setText("");
            return true;

        }else{
            incorect.setText("Mail or Password is incorect!");
            return false;
        }
    }

    @FXML
    private void back(ActionEvent e) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("SpaceShooter.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage)((Node)e.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
}
