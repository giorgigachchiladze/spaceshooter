package com.example.spaceshooter;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class MainManu {

    @FXML
    private void PLAY(ActionEvent e) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("PLAY.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage)((Node)e.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }


    @FXML
    private void LEADERBOARD(ActionEvent e) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("LEADERBOARD.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage)((Node)e.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void SETTINGS(ActionEvent e) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("SETTINGS.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage)((Node)e.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void Back(ActionEvent e) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("SpaceShooter.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage)((Node)e.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }


}
