package com.example.spaceshooter;

import javafx.fxml.FXML;
import javafx.scene.control.Button;


public class MainManu {

    @FXML
    private Button Play;
    @FXML
    private Button Leaderboard;
    @FXML
    private Button Settings;


}
