package com.example.spaceshooter;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;


import java.io.IOException;
import java.sql.*;

public class SignUp {

    @FXML
    private Label mailLabel;
    @FXML
    private Label passwordLabel;
    @FXML
    private Label repeatedPasswordLabel;
    @FXML
    private TextField mail;
    @FXML
    private TextField password;
    @FXML
    private  TextField repeatedPassword;
    @FXML
    private RadioButton optionA;
    @FXML
    private RadioButton optionB;
    @FXML
    private ToggleGroup group1;
    @FXML
    private AnchorPane anchorPane;
    @FXML
    private Button ageButton;
    @FXML
    private TextField ageText;
    @FXML
    private Rectangle rectangle;
    @FXML
    private Label ageLabel;
    @FXML
    private Label genderLabel;


    boolean check = true;

    Integer age = 0;

    RadioButton selectedRadio = new RadioButton();

    @FXML
    private void handleRadioSelection(ActionEvent e) {
         selectedRadio = (RadioButton) group1.getSelectedToggle();
    }



    @FXML
    private void Age(ActionEvent e)
    {
        anchorPane.setOnMouseDragged(a -> {
            if(a.getX() >= 117 && a. getX() <= 217)
            {
                ageButton.setLayoutX(a.getX());
                rectangle.setLayoutX(a.getX());
                age = (int) a.getX() - 117;
                ageText.setText(age.toString());

            }
            else if(a.getX() < 117)
            {
                ageButton.setLayoutX(117);
                rectangle.setLayoutX(117);
                ageText.setText("0");
            }
            else if(a.getX() > 217) {
                ageButton.setLayoutX(217);
                rectangle.setLayoutX(217);
                ageText.setText("100");
            }
            if(a.getX() < 127)
            {
                ageLabel.setText("should be only 10-100");
            }
            else ageLabel.setText(" ");
        });
    }

    @FXML
    private void enter(ActionEvent e)
    {
        if(ageText.getText().isEmpty())
        {
            ageLabel.setText("This field must be filled in");
        }
        else if(Integer.valueOf(ageText.getText()) >= 10 && Integer.valueOf(ageText.getText()) <= 100){
            rectangle.setLayoutX(Integer.valueOf(ageText.getText()) + 117);
            ageButton.setLayoutX(Integer.valueOf(ageText.getText()) + 117);
            age = Integer.valueOf(ageText.getText());
            ageLabel.setText(" ");
        }
        else ageLabel.setText("should be only 10-100");
    }


    @FXML
    private void SignUp (ActionEvent e) throws SQLException, IOException {
        check = true;
        if(ageLabel.getText().equals("should be only 10-100")){
            check = false;
        }
        else if(ageText.getText().isEmpty())
        {
            ageLabel.setText("This field must be filled in");
            check = false;
        }
        else{
            ageLabel.setText(" ");
        }
        Connection connection
                = DriverManager.getConnection(HelloApplication.url, HelloApplication.usename, HelloApplication.password);
        String mail1 = mail.getText();
        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery("select * from users");
        boolean indicator = false;
        while (resultSet.next()) {
            if (mail1.equals(resultSet.getString(1))) {
                indicator = true;
                break;
            }
        }

        if (mail.getText().isEmpty()) {
            mailLabel.setText("This field must be filled in");
            check = false;
        } else if(indicator){
            mailLabel.setText("Mail already exists");
            check = false;
        }
        else{
            mailLabel.setText(" ");
        }

        if (password.getText().isEmpty()) {
            passwordLabel.setText("This field must be filled in");
            check = false;
        } else if (password.getText().length() < 8 || password.getText().length() > 28) {
            passwordLabel.setText("password must contain only 8-28 characters");
            check = false;

        } else {
            passwordLabel.setText(" ");
        }
        if (repeatedPassword.getText().isEmpty()) {
            repeatedPasswordLabel.setText("This field must be filled in");
            check = false;
        } else if (repeatedPassword.getText().equals(password.getText())) {
            repeatedPasswordLabel.setText(" ");
        } else{
            repeatedPasswordLabel.setText("Passwords doesn't matches");
            check = false;
        }
        if(selectedRadio.getText().isEmpty())
        {
            genderLabel.setText("Should choice one");
            check = false;
        }
        else {
            genderLabel.setText(" ");
        }
        if(ageText.getText().equals("0"))
        {
            ageLabel.setText("should be only 10-100");
            check = false;
        }

        if(check){
            statement.execute("INSERT INTO users (mail, password, gender, age) VALUES ('"
                    + mail.getText() + "', '"
                    + password.getText() + "', '"
                    + selectedRadio.getText() + "', "
                    + ageText.getText() + ");");
            Parent root = FXMLLoader.load(getClass().getResource("Log In.fxml"));
            Scene scene = new Scene(root);
            Stage stage = (Stage)((Node)e.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        }


    }

    @FXML
    private void back(ActionEvent e) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("SpaceShooter.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage)((Node)e.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

}